var require = meteorInstall({"imports":{"api":{"billing.js":["meteor/meteor","meteor/mongo","./product.js","./cart.js","meteor/email",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// imports/api/billing.js                                                                            //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
module.export({Invoice:function(){return Invoice}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var Product;module.import('./product.js',{"Product":function(v){Product=v}});var Cart;module.import('./cart.js',{"Cart":function(v){Cart=v}});var Email;module.import('meteor/email',{"Email":function(v){Email=v}});
                                                                                                     // 2
                                                                                                     // 3
                                                                                                     // 4
                                                                                                     // 5
                                                                                                     //
var Invoice = new Mongo.Collection('invoice');                                                       // 7
                                                                                                     //
// Invoice.helpers({                                                                                 // 9
//     invoiceproduct:function(){                                                                    // 10
//       console.log('blt');                                                                         // 11
//         return Product.findOne({_id:this.product});                                               // 12
//     }                                                                                             // 13
// });                                                                                               // 14
                                                                                                     //
if (Meteor.isServer) {                                                                               // 16
  Meteor.publish('invoices', function (invoiceId) {                                                  // 17
    return Invoice.find({ _id: invoiceId });                                                         // 18
  });                                                                                                // 19
}                                                                                                    // 20
                                                                                                     //
Invoice.before.insert(function (userId, doc) {                                                       // 22
  doc.createdAt = new Date();                                                                        // 23
  doc.buyerId = Meteor.userId();                                                                     // 24
  doc.paid = false;                                                                                  // 25
});                                                                                                  // 26
                                                                                                     //
// Define gateway variable                                                                           // 28
var gateway;                                                                                         // 29
                                                                                                     //
Meteor.startup(function () {                                                                         // 31
  var env;                                                                                           // 32
  // Pick Braintree environment based on environment defined in Meteor settings.                     // 33
  if (Meteor.settings['public'].env === 'Production') {                                              // 34
    env = Braintree.Environment.Production;                                                          // 35
  } else {                                                                                           // 36
    env = Braintree.Environment.Sandbox;                                                             // 37
  }                                                                                                  // 38
  // Initialize Braintree connection:                                                                // 39
  gateway = BrainTreeConnect({                                                                       // 40
    environment: env,                                                                                // 41
    publicKey: Meteor.settings['public'].BT_PUBLIC_KEY,                                              // 42
    privateKey: Meteor.settings['private'].BT_PRIVATE_KEY,                                           // 43
    merchantId: Meteor.settings['public'].BT_MERCHANT_ID                                             // 44
  });                                                                                                // 40
});                                                                                                  // 46
                                                                                                     //
Meteor.methods({                                                                                     // 48
  'billing.calculateClient': function () {                                                           // 49
    function billingCalculateClient() {                                                              // 48
      var total = {};                                                                                // 50
      total.price = 0;                                                                               // 51
      total.shipping = 0;                                                                            // 52
      var cart = Cart.find({ userId: Meteor.userId() }).fetch();                                     // 53
      total.cart = cart;                                                                             // 54
      for (var i = 0; i < cart.length; i++) {                                                        // 55
        var product = Product.findOne({ _id: cart[i].product });                                     // 56
        if (cart[i].shipping == 1) {                                                                 // 57
          total.shipping = total.shipping + Number(product.priceStShip);                             // 58
        } else if (cart[i].shipping == 2) {                                                          // 59
          total.shipping = total.shipping + Number(product.pricePrShip);                             // 60
        }                                                                                            // 61
        total.price += product.price * cart[i].qty;                                                  // 62
      }                                                                                              // 63
      total.price = total.price + total.shipping;                                                    // 64
      return total;                                                                                  // 65
    }                                                                                                // 66
                                                                                                     //
    return billingCalculateClient;                                                                   // 48
  }(),                                                                                               // 48
  'billing.getClientToken': function () {                                                            // 67
    function billingGetClientToken(clientId) {                                                       // 48
      var generateToken = Meteor.wrapAsync(gateway.clientToken.generate, gateway.clientToken);       // 68
      var options = {};                                                                              // 69
                                                                                                     //
      if (clientId) {                                                                                // 71
        options.clientId = clientId;                                                                 // 72
      }                                                                                              // 73
                                                                                                     //
      var response = generateToken(options);                                                         // 75
      return response.clientToken;                                                                   // 76
    }                                                                                                // 77
                                                                                                     //
    return billingGetClientToken;                                                                    // 48
  }(),                                                                                               // 48
                                                                                                     //
  // 'billing.btCreateCustomer'(){                                                                   // 78
  //   var user = Meteor.user();                                                                     // 79
                                                                                                     //
  //   var customerData = {                                                                          // 81
  //     email: user.emails[0].address                                                               // 82
  //   };                                                                                            // 83
                                                                                                     //
  //   // Calling the Braintree API to create our customer!                                          // 85
  //   gateway.customer.create(customerData, function(error, response){                              // 86
  //     if (error){                                                                                 // 87
  //       console.log(error);                                                                       // 88
  //     } else {                                                                                    // 89
  //       // If customer is successfuly created on Braintree servers,                               // 90
  //       // we will now add customer ID to our User                                                // 91
  //       // Meteor.users.update(user._id, {                                                        // 92
  //       //   $set: {                                                                              // 93
  //       //     customerId: response.customer.id                                                   // 94
  //       //   }                                                                                    // 95
  //       // });                                                                                    // 96
  //     }                                                                                           // 97
  //   });                                                                                           // 98
  // },                                                                                              // 99
  'billing.createTransaction': function () {                                                         // 100
    function billingCreateTransaction(nonceFromTheClient, price, invoiceId) {                        // 48
      var user = Meteor.user();                                                                      // 101
      // Let's create transaction.                                                                   // 102
      gateway.transaction.sale({                                                                     // 103
        amount: price,                                                                               // 104
        orderId: invoiceId,                                                                          // 105
        paymentMethodNonce: nonceFromTheClient, // Generated nonce passed from client                // 106
        options: {                                                                                   // 107
          submitForSettlement: true }                                                                // 108
      }, function (err, success) {                                                                   // 103
        if (err) {                                                                                   // 111
          console.log(err);                                                                          // 112
        } else {                                                                                     // 113
          // When payment's successful, add "paid" role to current invoice.                          // 114
          Invoice.update({ _id: invoiceId }, { $set: { paid: true } });                              // 115
        }                                                                                            // 116
      });                                                                                            // 117
    }                                                                                                // 118
                                                                                                     //
    return billingCreateTransaction;                                                                 // 48
  }(),                                                                                               // 48
  'billing.addInvoice': function () {                                                                // 119
    function billingAddInvoice(carts) {                                                              // 48
      var invId = Invoice.insert({ carts: carts });                                                  // 120
      return invId;                                                                                  // 121
    }                                                                                                // 122
                                                                                                     //
    return billingAddInvoice;                                                                        // 48
  }(),                                                                                               // 48
  'billing.deleteCarts': function () {                                                               // 123
    function billingDeleteCarts() {                                                                  // 48
      return Cart.remove({ userId: Meteor.userId() });                                               // 124
    }                                                                                                // 125
                                                                                                     //
    return billingDeleteCarts;                                                                       // 48
  }(),                                                                                               // 48
  'billing.updateInvoice': function () {                                                             // 126
    function billingUpdateInvoice(invoiceId) {                                                       // 48
      return Invoice.update({ _id: invoiceId }, { $set: { paid: true } });                           // 127
    }                                                                                                // 128
                                                                                                     //
    return billingUpdateInvoice;                                                                     // 48
  }(),                                                                                               // 48
  'billing.sendEmail': function () {                                                                 // 129
    function billingSendEmail(to, fromWhom, subject, html) {                                         // 48
                                                                                                     //
      this.unblock();                                                                                // 131
                                                                                                     //
      Email.send({                                                                                   // 133
        to: to,                                                                                      // 134
        from: fromWhom,                                                                              // 135
        subject: subject,                                                                            // 136
        html: html                                                                                   // 137
      });                                                                                            // 133
    }                                                                                                // 139
                                                                                                     //
    return billingSendEmail;                                                                         // 48
  }()                                                                                                // 48
});                                                                                                  // 48
///////////////////////////////////////////////////////////////////////////////////////////////////////

}],"cart.js":["meteor/meteor","meteor/mongo","./product.js",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// imports/api/cart.js                                                                               //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
module.export({Cart:function(){return Cart}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var Product;module.import('./product.js',{"Product":function(v){Product=v}});
                                                                                                     // 2
                                                                                                     // 3
                                                                                                     //
var Cart = new Mongo.Collection('cart');                                                             // 5
                                                                                                     //
Cart.helpers({                                                                                       // 7
  cartproduct: function () {                                                                         // 8
    function cartproduct() {                                                                         // 8
      return Product.findOne({ _id: this.product });                                                 // 9
    }                                                                                                // 10
                                                                                                     //
    return cartproduct;                                                                              // 8
  }()                                                                                                // 8
});                                                                                                  // 7
                                                                                                     //
Cart.allow({                                                                                         // 14
  'insert': function () {                                                                            // 15
    function insert(userId, doc) {                                                                   // 14
      return userId;                                                                                 // 16
    }                                                                                                // 17
                                                                                                     //
    return insert;                                                                                   // 14
  }(),                                                                                               // 14
  'update': function () {                                                                            // 18
    function update() {                                                                              // 14
      return true;                                                                                   // 19
    }                                                                                                // 20
                                                                                                     //
    return update;                                                                                   // 14
  }()                                                                                                // 14
});                                                                                                  // 14
                                                                                                     //
if (Meteor.isServer) {                                                                               // 24
  Meteor.publish('usercart', function () {                                                           // 25
    return Cart.find({ userId: this.userId });                                                       // 26
  });                                                                                                // 27
}                                                                                                    // 28
                                                                                                     //
Meteor.methods({                                                                                     // 30
  'cart.addItem': function () {                                                                      // 31
    function cartAddItem(product, qty, option, shipMethod) {                                         // 30
      var exists = Cart.findOne({ userId: Meteor.userId(), product: product, option: option });      // 32
      if (exists) {                                                                                  // 33
        return Cart.update(exists, { $inc: { qty: qty } });                                          // 34
        // add a note for a client: you already  have this product in your cart. You can increase the quantity by vsiting your cart.
      }                                                                                              // 36
      return Cart.insert({ userId: Meteor.userId(), product: product, qty: qty, option: option, shipping: shipMethod });
    }                                                                                                // 38
                                                                                                     //
    return cartAddItem;                                                                              // 30
  }(),                                                                                               // 30
  'cart.updateQuant': function () {                                                                  // 39
    function cartUpdateQuant(id, newQuant) {                                                         // 30
      return Cart.update({ _id: id }, { $set: { qty: newQuant } });                                  // 40
    }                                                                                                // 41
                                                                                                     //
    return cartUpdateQuant;                                                                          // 30
  }(),                                                                                               // 30
  'cart.updateOption': function () {                                                                 // 42
    function cartUpdateOption(id, newOption) {                                                       // 30
      return Cart.update({ _id: id }, { $set: { option: newOption } });                              // 43
    }                                                                                                // 44
                                                                                                     //
    return cartUpdateOption;                                                                         // 30
  }(),                                                                                               // 30
  'cart.updateShip': function () {                                                                   // 45
    function cartUpdateShip(id, newShip) {                                                           // 30
      return Cart.update({ _id: id }, { $set: { shipping: newShip } });                              // 46
    }                                                                                                // 47
                                                                                                     //
    return cartUpdateShip;                                                                           // 30
  }(),                                                                                               // 30
  'cart.userChange': function () {                                                                   // 48
    function cartUserChange(UserShipAddress) {                                                       // 30
      Meteor.users.update({ _id: Meteor.userId() }, { $set: { profile: UserShipAddress } });         // 49
    }                                                                                                // 50
                                                                                                     //
    return cartUserChange;                                                                           // 30
  }(),                                                                                               // 30
  'cart.userBillChange': function () {                                                               // 51
    function cartUserBillChange(UserBillAddress) {                                                   // 30
      Meteor.users.update({ _id: Meteor.userId() }, { $set: { UserBillAddress: UserBillAddress } });
    }                                                                                                // 53
                                                                                                     //
    return cartUserBillChange;                                                                       // 30
  }(),                                                                                               // 30
  'cart.deleteKorb': function () {                                                                   // 54
    function cartDeleteKorb(KorbId) {                                                                // 30
      Cart.remove(KorbId);                                                                           // 55
    }                                                                                                // 56
                                                                                                     //
    return cartDeleteKorb;                                                                           // 30
  }()                                                                                                // 30
});                                                                                                  // 30
///////////////////////////////////////////////////////////////////////////////////////////////////////

}],"category.js":["meteor/meteor","meteor/mongo",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// imports/api/category.js                                                                           //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
module.export({Category:function(){return Category}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});
                                                                                                     // 2
                                                                                                     //
var Category = new Mongo.Collection('category');                                                     // 4
                                                                                                     //
if (Meteor.isServer) {                                                                               // 6
                                                                                                     //
  Category.allow({                                                                                   // 8
    'insert': function () {                                                                          // 9
      function insert(userId, doc) {                                                                 // 8
        return doc;                                                                                  // 10
      }                                                                                              // 11
                                                                                                     //
      return insert;                                                                                 // 8
    }()                                                                                              // 8
  });                                                                                                // 8
                                                                                                     //
  Meteor.publish('category', function () {                                                           // 14
    return Category.find({});                                                                        // 15
  });                                                                                                // 16
}                                                                                                    // 17
                                                                                                     //
Meteor.methods({                                                                                     // 20
  'category.insert': function () {                                                                   // 21
    function categoryInsert(categoryName) {                                                          // 20
      if (Category.findOne({ name: categoryName }) == null) {                                        // 22
        return Category.insert({ name: categoryName });                                              // 23
      } else {                                                                                       // 24
        var cat = Category.findOne({ name: categoryName });                                          // 25
        return cat._id;                                                                              // 26
      }                                                                                              // 27
    }                                                                                                // 28
                                                                                                     //
    return categoryInsert;                                                                           // 20
  }()                                                                                                // 20
});                                                                                                  // 20
///////////////////////////////////////////////////////////////////////////////////////////////////////

}],"product.js":["meteor/meteor","meteor/mongo","./category.js",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// imports/api/product.js                                                                            //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
module.export({Product:function(){return Product}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var Category;module.import('./category.js',{"Category":function(v){Category=v}});
                                                                                                     // 2
                                                                                                     // 3
                                                                                                     //
var Product = new Mongo.Collection('product');                                                       // 5
                                                                                                     //
if (Meteor.isServer) {                                                                               // 7
                                                                                                     //
  Product.allow({                                                                                    // 9
    'insert': function () {                                                                          // 10
      function insert(userId, doc) {                                                                 // 9
        return doc;                                                                                  // 11
      }                                                                                              // 12
                                                                                                     //
      return insert;                                                                                 // 9
    }(),                                                                                             // 9
    'remove': function () {                                                                          // 13
      function remove(userId, doc) {                                                                 // 9
        return doc;                                                                                  // 14
      }                                                                                              // 15
                                                                                                     //
      return remove;                                                                                 // 9
    }()                                                                                              // 9
  });                                                                                                // 9
                                                                                                     //
  Meteor.publish('product', function () {                                                            // 18
    return Product.find({});                                                                         // 19
  });                                                                                                // 20
                                                                                                     //
  Meteor.publish('catProducts', function (categoryName) {                                            // 22
    var catId = Category.findOne({ name: categoryName })._id;                                        // 23
    return Product.find({ category: catId });                                                        // 24
  });                                                                                                // 25
}                                                                                                    // 27
                                                                                                     //
Meteor.methods({                                                                                     // 30
  'product.addItem': function () {                                                                   // 31
    function productAddItem(product) {                                                               // 30
      return Product.insert(product);                                                                // 32
    }                                                                                                // 33
                                                                                                     //
    return productAddItem;                                                                           // 30
  }(),                                                                                               // 30
  'product.remove': function () {                                                                    // 34
    function productRemove(productId) {                                                              // 30
      return Product.remove({ _id: productId });                                                     // 35
    }                                                                                                // 36
                                                                                                     //
    return productRemove;                                                                            // 30
  }()                                                                                                // 30
});                                                                                                  // 30
///////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"main.js":["meteor/meteor","../imports/api/product.js","../imports/api/cart.js","../imports/api/category.js","../imports/api/billing.js",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// server/main.js                                                                                    //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Product;module.import('../imports/api/product.js',{"Product":function(v){Product=v}});module.import('../imports/api/product.js');module.import('../imports/api/cart.js');module.import('../imports/api/category.js');module.import('../imports/api/billing.js');
                                                                                                     // 2
                                                                                                     //
                                                                                                     // 4
                                                                                                     // 5
                                                                                                     // 6
                                                                                                     // 7
                                                                                                     //
Meteor.startup(function () {                                                                         // 11
  // code to run on server at startup                                                                // 12
  //   Meteor.publish('allUsers', function() {                                                       // 13
  //     cursor = Meteor.users.find({});                                                             // 14
  //     console.log(cursor.count());                                                                // 15
  //     return cursor;                                                                              // 16
  // });                                                                                             // 17
  Product._ensureIndex({ "category": 1 });                                                           // 18
  process.env.MAIL_URL = 'smtp://info@luludeals.com:Mumija99@smtp.mailgun.org:587';                  // 19
});                                                                                                  // 20
///////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
