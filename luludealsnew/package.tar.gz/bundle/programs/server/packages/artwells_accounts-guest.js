(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var Accounts = Package['accounts-base'].Accounts;

/* Package-scope variables */
var AccountsGuest, Moniker, res, guestname, guest;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// packages/artwells_accounts-guest/packages/artwells_accounts-guest.js                                       //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/artwells:accounts-guest/accounts-guest.js                                                   //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
AccountsGuest = {};                                                                                     // 1
if (typeof AccountsGuest.forced === "undefined") {                                                      // 2
	AccountsGuest.forced = true; /*default to making loginVisitor automatic, and on logout*/               // 3
}                                                                                                       // 4
if (typeof AccountsGuest.enabled === "undefined") {                                                     // 5
	AccountsGuest.enabled = true; /* on 'false'  Meteor.loginVisitor() will fail */                        // 6
}                                                                                                       // 7
if (typeof AccountsGuest.name === "undefined") {                                                        // 8
  AccountsGuest.name = false; /* defaults to returning "null" for user's name */                        // 9
}                                                                                                       // 10
                                                                                                        // 11
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/artwells:accounts-guest/accounts-guest-server.js                                            //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
Moniker = Npm.require('moniker');                                                                       // 1
                                                                                                        // 2
Accounts.removeOldGuests = function (before) {                                                          // 3
    if (typeof before === 'undefined') {                                                                // 4
        before = new Date();                                                                            // 5
        before.setHours(before.getHours() - 1);                                                         // 6
    }                                                                                                   // 7
    res = Meteor.users.remove({createdAt: {$lte: before}, 'profile.guest': true});                      // 8
    //res = Meteor.users.remove( {'profile.guest': true});                                              // 9
    return res;                                                                                         // 10
};                                                                                                      // 11
                                                                                                        // 12
/* adapted from pull-request https://github.com/dcsan                                                   // 13
* See https://github.com/artwells/meteor-accounts-guest/commit/28cbbf0eca2d80f78925ac619abf53d0769c0d9d // 14
*/                                                                                                      // 15
Meteor.methods({                                                                                        // 16
    createGuest: function (email)                                                                       // 17
    {                                                                                                   // 18
        check(email, Match.OneOf(String, null, undefined));                                             // 19
                                                                                                        // 20
        /* if explicitly disabled, happily do nothing */                                                // 21
        if (AccountsGuest.enabled === false){                                                           // 22
            return true;                                                                                // 23
        }                                                                                               // 24
                                                                                                        // 25
        //    count = Meteor.users.find().count() + 1                                                   // 26
        if (AccountsGuest.name === true) {                                                              // 27
          guestname = Moniker.choose();                                                                 // 28
          // Just in case, let's make sure this name isn't taken                                        // 29
          while (Meteor.users.find({username:guestname}).count() > 0) {                                 // 30
            guestname = Moniker.choose();                                                               // 31
          }                                                                                             // 32
        } else {                                                                                        // 33
          guestname = "guest-#" + Random.id()                                                           // 34
        }                                                                                               // 35
                                                                                                        // 36
        if (!email) {                                                                                   // 37
            email = guestname + "@example.com";                                                         // 38
        }                                                                                               // 39
                                                                                                        // 40
        guest = {                                                                                       // 41
            username: guestname,                                                                        // 42
            email: email,                                                                               // 43
            profile: {guest: true},                                                                     // 44
            password: Meteor.uuid(),                                                                    // 45
        };                                                                                              // 46
        Accounts.createUser(guest);                                                                     // 47
        //    console.log("createGuest" + guestname);                                                   // 48
        return guest;                                                                                   // 49
    }                                                                                                   // 50
});                                                                                                     // 51
                                                                                                        // 52
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['artwells:accounts-guest'] = {}, {
  AccountsGuest: AccountsGuest
});

})();
